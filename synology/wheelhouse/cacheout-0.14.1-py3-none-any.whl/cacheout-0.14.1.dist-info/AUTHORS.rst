Authors
=======


Lead
----

- Derrick Gilland, dgilland@gmail.com, `dgilland@github <https://github.com/dgilland>`_


Contributors
------------

- John Bergvall , `johnbergvall@github <https://github.com/johnbergvall>`_
- AllinolCP, `AllinolCP@github <https://github.com/AllinolCP>`_
