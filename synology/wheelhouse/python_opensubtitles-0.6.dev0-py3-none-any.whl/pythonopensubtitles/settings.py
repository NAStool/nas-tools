class Settings(object):
    OPENSUBTITLES_SERVER = 'http://api.opensubtitles.org/xml-rpc'
    USER_AGENT = 'TemporaryUserAgent'
    LANGUAGE = 'en'
