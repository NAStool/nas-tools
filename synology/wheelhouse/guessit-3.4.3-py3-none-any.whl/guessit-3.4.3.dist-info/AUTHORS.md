Copyright (c) 2011 - 2020, The GuessIt contributors.

GuessIt is an opensource project written and maintained by passionate
people.

If you feel your name should belong to this list, please [open an
issue](https://github.com/guessit/guessit/issues)

Author and contributors of current guessit version (`2.x`/`3.x`):

-   Rémi Alvergnat &lt;<toilal.dev@gmail.com>&gt;
-   Rato &lt;<rato.aq2@gmail.com>&gt;

Author and contributors of initial guessit version (`0.x`/`1.x`):

-   Nicolas Wack &lt;<wackou@gmail.com>&gt;
-   Ricard Marxer &lt;<ricardmp@gmail.com>&gt;
