from terminal_layout.extensions.choice.choice import Choice,StringStyle
